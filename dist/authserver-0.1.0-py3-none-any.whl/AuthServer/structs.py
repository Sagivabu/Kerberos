import struct
from typing import Optional

class Payload:
    def __init__(self, client_id: str, version: str, code: str, payload: Optional[str]):
        self.client_id = client_id[:16]  # Limit to 16 bytes
        self.version = version[:1]  # Limit to 1 byte
        self.code = code[:2]  # Limit to 2 bytes
        self.payload_size = len(payload.encode('utf-8')) if payload else 0 # len() return int (= 4 bytes)
        self.payload = payload

    def pack(self) -> bytes:
        ''' object method to pack the object'''
        client_id_bytes = self.client_id.encode('utf-8')
        version_bytes = self.version.encode('utf-8')
        code_bytes = self.code.encode('utf-8')

        if self.payload is not None:
            payload_bytes = self.payload.encode('utf-8')
        else:
            payload_bytes = b''

        format_string = f'<16s1s2sI{len(payload_bytes)}s'
        return struct.pack(format_string, client_id_bytes, version_bytes, code_bytes, self.payload_size, payload_bytes)
    
    @classmethod
    def unpack(cls, data: bytes) -> 'Payload':
        ''' class method to unpack data and creating new object \n
            'data' - bytes object (=usually Payload object that is after 'pack' method)\n
            return - new Payload object'''
        format_string = '<16s1s2sI'
        size_of_header = struct.calcsize(format_string)
        header = struct.unpack(format_string, data[:size_of_header])
        payload = data[size_of_header:]
        return cls(header[0].decode('utf-8'), header[1].decode('utf-8'), header[2].decode('utf-8'), payload.decode('utf-8'))