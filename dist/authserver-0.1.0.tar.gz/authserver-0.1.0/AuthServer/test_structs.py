from dataclasses import dataclass
from AuthServer.structs import Payload 

print("hi2")

@dataclass
class Test_Payload():
    client_id = '123'
    version = '1'
    code = 'AB12'
    payload = f"This message is from client_id '{client_id}' with version '{version}' and code '{code}'."

    #@property
    def test(self):
        print('hi')
        pl = Payload(client_id=self.client_id , version=self.version, code=self.code, payload=self.payload)
        objectbytes = pl.pack()
        newpl = pl.unpack(objectbytes)
        if ((self.client_id == newpl.client_id) and
               (self.version == newpl.version) and
               (self.code == newpl.code) and
               (self.payload == newpl.payload)):
            print("Yes")
        else:
            print('No')
    
    
def test():
    Test_Payload().test()

test()



        